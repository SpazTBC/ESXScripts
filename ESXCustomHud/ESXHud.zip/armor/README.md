Items that should be added into your ox_inventory

['bulletproof'] = {
    label = 'Bulletproof Vest',
    weight = 3,
    stack = false,
    close = true,
    description = 'Protects against bullets'
},

also ensure you turn AutomaticUse to true in config.lua


To make this a usable item add this into your esx_optionalneeds

ESX.RegisterUsableItem('bulletproof', function(source)
    local xPlayer = ESX.GetPlayerFromId(source)

    xPlayer.removeInventoryItem('bulletproof', 1)

    -- Add armor to the player
    TriggerClientEvent('esx_armormodifier:addArmor', source)

    TriggerClientEvent('esx:showNotification', source, TranslateCap('used_bulletproof'))
end)