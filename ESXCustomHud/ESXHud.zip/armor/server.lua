local ESX = exports["es_extended"]:getSharedObject()

-- Server event to remove armor item and trigger client-side armor application
RegisterServerEvent('esx_armormodifier:removeArmorItem')
AddEventHandler('esx_armormodifier:removeArmorItem', function()
    local xPlayer = ESX.GetPlayerFromId(source)
    
    if xPlayer.getInventoryItem(Config.ArmorItemName).count > 0 then
        xPlayer.removeInventoryItem(Config.ArmorItemName, 1)
        TriggerClientEvent('esx_armormodifier:useArmor', source)
    else
        xPlayer.showNotification('You don\'t have any body armor.')
    end
end)

-- For ox_inventory integration
if Config.AutomaticUse then
    ESX.RegisterUsableItem(Config.ArmorItemName, function(source)
        TriggerClientEvent('esx_armormodifier:useArmor', source)
        local xPlayer = ESX.GetPlayerFromId(source)
        xPlayer.removeInventoryItem(Config.ArmorItemName, 1)
    end)
end