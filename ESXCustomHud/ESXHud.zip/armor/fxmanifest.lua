fx_version 'cerulean'
game 'gta5'

author 'Your Name'
description 'ESX Armor Modifier'
version '1.0.0'

shared_scripts {
    '@es_extended/imports.lua',
    'config.lua'
}

client_scripts {
    'client.lua'
}

server_scripts {
    'server.lua'
}

dependencies {
    'es_extended'
}