local ESX = exports["es_extended"]:getSharedObject()
local extraArmor = 0

-- Function to add armor
local function AddArmor()
    local playerPed = PlayerPedId()
    local currentArmor = GetPedArmour(playerPed)
    
    if currentArmor < 100 then
        -- Fill up to 100 first
        local armorToAdd = math.min(Config.ArmorToAdd, 100 - currentArmor)
        SetPedArmour(playerPed, currentArmor + armorToAdd)
        
        -- If there's any left over, add to extraArmor
        if Config.ArmorToAdd > armorToAdd then
            extraArmor = math.min(extraArmor + (Config.ArmorToAdd - armorToAdd), Config.MaxArmor - 100)
        end
    else
        -- If already at 100, just add to extraArmor
        extraArmor = math.min(extraArmor + Config.ArmorToAdd, Config.MaxArmor - 100)
    end
    
    -- Update HUD
    local totalArmor = GetPedArmour(playerPed) + extraArmor
    local armorCount = math.ceil(totalArmor / 100)
    TriggerEvent('custom_hud:updateArmorCount', armorCount, totalArmor)
end

-- Event handler for using armor item
RegisterNetEvent('esx_armormodifier:addArmor')
AddEventHandler('esx_armormodifier:addArmor', function()
    local playerPed = PlayerPedId()
    local currentArmor = GetPedArmour(playerPed)
    
    if currentArmor < 100 then
        -- Fill up to 100 first
        local armorToAdd = math.min(Config.ArmorToAdd, 100 - currentArmor)
        SetPedArmour(playerPed, currentArmor + armorToAdd)
        
        -- If there's any left over, add to extraArmor
        if Config.ArmorToAdd > armorToAdd then
            extraArmor = math.min(extraArmor + (Config.ArmorToAdd - armorToAdd), Config.MaxArmor - 100)
        end
    else
        -- If already at 100, just add to extraArmor
        extraArmor = math.min(extraArmor + Config.ArmorToAdd, Config.MaxArmor - 100)
    end
    
    -- Update HUD
    local totalArmor = GetPedArmour(playerPed) + extraArmor
    local armorCount = math.ceil(totalArmor / 100)
    TriggerEvent('custom_hud:updateArmorCount', armorCount, totalArmor)
end)

-- Thread to manage extraArmor
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1000)  -- Check every second
        local playerPed = PlayerPedId()
        local currentArmor = GetPedArmour(playerPed)
        
        if currentArmor < 100 and extraArmor > 0 then
            local armorToAdd = math.min(100 - currentArmor, extraArmor)
            SetPedArmour(playerPed, currentArmor + armorToAdd)
            extraArmor = extraArmor - armorToAdd
        end
        
        local totalArmor = currentArmor + extraArmor
        local armorCount = math.ceil(totalArmor / 100)
        TriggerEvent('custom_hud:updateArmorCount', armorCount, totalArmor)
    end
end)