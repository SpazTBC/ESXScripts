Config = {}

Config.ArmorItemName = 'bulletproof' -- The name of your armor item in the ESX database
Config.ArmorToAdd = 100 -- Amount of armor to add (50 = 2 bars)
Config.MaxArmor = 200 -- Maximum armor value
Config.AutomaticUse = false