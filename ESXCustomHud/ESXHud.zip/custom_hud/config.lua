Config = {}
Config.ServerAbbreviation = "PLUGRP" -- Change this to your server's abbreviation